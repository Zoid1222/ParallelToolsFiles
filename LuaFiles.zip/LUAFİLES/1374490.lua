-- Generated with Luie @ https://lua.tools/
-- 1374490 - RuneScape: Dragonwilds
-- Generated 2026-09-15 16:08:36 UTC
-- # Depots (Total/DLC/Shared): 5/2/2

-- Main AppID
addappid(1374490, 1, "735dc070f781ea410ecf7ffbdf051b5fdb8d98ea6054aa34aea78625b4a3e594")

-- Main Depots
addappid(1374491, 1, "e1a3b5ad6a0fbda32b1fceadce8be5fe365e6c98dcc654bfdef62b6aa01f48d5") -- (windows, 64-bit)
setManifestid(1374491, "5108380847188890293", 42551545254)

-- DLC's (no depot keys required)
addappid(3501790) -- RuneScape: Dragonwilds Early Adopter DLC
addappid(4908050) -- RuneScape: Dragonwilds - Deluxe Edition Upgrade

-- DLC's (with depot keys)
-- RuneScape: Dragonwilds Early Adopter Soundtrack (AppID: 3637470)
addappid(3637470)
addappid(3637471, 1, "263c8802f36928dec41a97d9928d32e02d03586113185704040f3b41f14d13d6")
setManifestid(3637471, "8659772693087272583", 18361244)
addappid(3637472, 1, "e2eb8af830733a56f38d33af3efd1a36f12b294b39f727830471099458bcfd43")
setManifestid(3637472, "7005123597752440638", 101062239)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
