-- ============================================================
-- CRACK WORLD AUTOMATED STEAM CONFIG
-- Generated and compiled by Crack World
-- ============================================================
-- Title:   Call of Duty®: Modern Warfare® 2 (2009)
-- AppID:   10180
-- Created: July 15, 2026 at 12:40:58 PM
-- Discord: https://discord.gg/crackworld
-- ============================================================

-- [Core Application]
addappid(10180) -- Call of Duty®: Modern Warfare® 2 (2009)

-- [Content Depots]
addappid(10181, 1, "d70303bb22551541ac74e48fab183d727cc00c5598fd6b8ac6881e9661f51796")
setManifestid(10181, "6601306686778045038", 1775360)
addappid(10182, 1, "98e730672197195300951a3d2f198c16ddfd4cc6d6f882d51d4451e07e1f56d4")
setManifestid(10182, "4063260329988186194", 4417798688)
addappid(10183, 1, "9d6d7892bb063f0994946afbf4e2dbe2376c4e38fd5499197b04d9739e755eab")
setManifestid(10183, "8707803059832053468", 0)
addappid(10185, 1, "bfb1650ac051bc56aa5070292ff58e1d7c51cca2490d854920f33304768b9ebc")
setManifestid(10185, "6960622809953595829", 0)
addappid(10186, 1, "34794e682272e97d0eaf302225f29e5768eaf13597588eb377b38be229197376")
setManifestid(10186, "6253063533272841787", 0)
addappid(10187, 1, "3f43d1151fcabffd59378e8126ea4e3b3822cf052e97c4bded63f9d2dc9c9ba1")
setManifestid(10187, "5447045943202156387", 0)
addappid(10188, 1, "dec6cdf03b13ce8882acaa2326a5ad546c218e36fe6ea031ff62349b007b74da")
setManifestid(10188, "6075992503597705494", 0)
addappid(10189, 1, "7f06a5d7663f4910db0d0c5ad3bbce302b70c1ccb4acf10245a425d1fab3efed")
setManifestid(10189, "1493308596121358900", 0)
addappid(10191, 1, "4b75b8d33e2d902e031e61b3666f029ab98ac47669b527b0a10237de18f4973d")
setManifestid(10191, "5365446663453490899", 0)
addappid(10192, 1, "4921666a58dbd848cabb65af356be86b94ade0dd89b599c9a5d9e14e221e2e64")
setManifestid(10192, "246258347768300127", 0)
addappid(10193, 1, "4fef095309f586b62847fab74e063f606e4e4e645b10b2519deb61a70f595cc4")
setManifestid(10193, "5456705176131695752", 0)
addappid(278280, 1, "c2388d5b10307263ca1f6dff3abc196a1cf9714164b643f9de97cf9b275ea2a5")
setManifestid(278280, "3619648325982091147", 4310418656)
addappid(278281, 1, "f23ffe3dc1f83a65f99dd3ebd1f8d840875995e4b9a4a09e2b77bc0e133a4f48")
setManifestid(278281, "8081965988729392508", 10297152)
addappid(278282, 1, "4cb28ace16dd3c200f693690509511b2ac50678a1085b25551e09b259331408f")
setManifestid(278282, "3664267140507507825", 7682603680)
addappid(278283, 1, "8f071c3dcae93458e00a7a4f1df7a122d95fb434a0a40fc5e3d7778a2818582a")
setManifestid(278283, "6313141199869918175", 7667516992)
addappid(278284, 1, "5d57c67bb0c65020f52183653a46fee36f75565706cf5211a90a1bdf05576eda")
setManifestid(278284, "4009187078934820154", 7813348160)
addappid(278285, 1, "88abe833e24b8116c84a5b0f7b85feafc4f1b9605c80732208b31a3fe856cfdf")
setManifestid(278285, "4684911959805635804", 7687154768)
addappid(278286, 1, "7a1dc16d0fb62b22ffec23b424d1244bce11cc56c717dd975c75204f0ef25ff1")
setManifestid(278286, "4006477255675382643", 7733690592)

-- [Shared Dependencies]
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
setManifestid(228989, "5753583882400741046", 25108528)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
setManifestid(228990, "1829726630299308803", 100658080)

-- ============================================================
-- Total Depots: 20
-- Shared Depots: 2
-- DLCs:         0
-- ============================================================
