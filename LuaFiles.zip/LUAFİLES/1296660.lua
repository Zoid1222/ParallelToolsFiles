-- ============================================================
-- CRACK WORLD AUTOMATED STEAM CONFIG
-- Generated and compiled by Crack World
-- ============================================================
-- Title:   Wartorn
-- AppID:   1296660
-- Created: July 15, 2026 at 01:20:20 PM
-- Discord: https://discord.gg/crackworld
-- ============================================================

-- [Core Application]
addappid(1296660) -- Wartorn

-- [Content Depots]
addappid(1296661, 1, "f226cf79722bb1a23a7669cda4d2e8daf468613f46016c108b74746545ff772e")
setManifestid(1296661, "106281097406991030", 7266196928)
addappid(1296662, 1, "ee8a4233e3ba20aaf3907b5ab592c9a6ff2d9844bfffe0ab68f57f7293ab7407")
setManifestid(1296662, "8488197712668550433", 145727520)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a")
setManifestid(229005, "7992454656023763365", 62722592)

-- [Shared Dependencies]
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
setManifestid(228989, "5753583882400741046", 25108528)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
setManifestid(228990, "1829726630299308803", 100658080)

-- ============================================================
-- Total Depots: 5
-- Shared Depots: 2
-- DLCs:         0
-- ============================================================
