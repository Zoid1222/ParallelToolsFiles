-- ============================================================
-- CRACK WORLD AUTOMATED STEAM CONFIG
-- Generated and compiled by Crack World
-- ============================================================
-- Title:   LEGO® 2K Drive
-- AppID:   1451810
-- Created: July 15, 2026 at 11:25:11 AM
-- Discord: https://discord.gg/crackworld
-- ============================================================

-- [Core Application]
addappid(1451810) -- LEGO® 2K Drive

-- [Content Depots]
addappid(1451811, 1, "f948c98d4d77df363d73427d4e1731afdfb10dc09a157b6256abcb15664c4f0f")
setManifestid(1451811, "6655680017474260221", 11888631552)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358")
setManifestid(228988, "6645201662696499616", 22411856)

-- [Shared Dependencies]
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
setManifestid(228990, "1829726630299308803", 100658080)
addappid(2353080, 1)
addappid(2353081, 1)
addappid(2353082, 1)
addappid(2353083, 1)
addappid(2353140, 1)
addappid(2353142, 1)
addappid(2353143, 1)
addappid(2353144, 1)
addappid(2353150, 1)
addappid(2353151, 1)
addappid(2353152, 1)
addappid(2353153, 1)
addappid(2353154, 1)
addappid(2353155, 1)

-- ============================================================
-- Total Depots: 17
-- Shared Depots: 15
-- DLCs:         0
-- ============================================================
