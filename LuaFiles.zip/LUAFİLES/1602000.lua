-- ============================================================
-- CRACK WORLD AUTOMATED STEAM CONFIG
-- Generated and compiled by Crack World
-- ============================================================
-- Title:   Hotel Architect
-- AppID:   1602000
-- Created: July 11, 2026 at 03:09:11 AM
-- Discord: https://discord.gg/crackworld
-- ============================================================

-- [Core Application]
addappid(1602000, ) -- Hotel Architect

-- [Content Depots]
addappid(1602001, 1, "0eae087f0db9be78952d7fae0ef01ab55a34cc7d8bae7f18ccc3379d89476fe7")
setManifestid(1602001, "1218171536094082804", 1234468240)

-- [Shared Dependencies]
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
setManifestid(228989, "5753583882400741046", 25108528)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
setManifestid(228990, "1829726630299308803", 100658080)

-- ============================================================
-- Total Depots: 3
-- Shared Depots: 2
-- DLCs:         0
-- ============================================================
