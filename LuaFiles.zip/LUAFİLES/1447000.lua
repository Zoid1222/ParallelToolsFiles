-- ============================================================
-- CRACK WORLD AUTOMATED STEAM CONFIG
-- Generated and compiled by Crack World
-- ============================================================
-- Title:   MotoGP™21
-- AppID:   1447000
-- Created: July 15, 2026 at 01:30:40 PM
-- Discord: https://discord.gg/crackworld
-- ============================================================

-- [Core Application]
addappid(1447000) -- MotoGP™21

-- [Content Depots]
addappid(1447001, 1, "63336d8971691a9f1c8a290b63703291352c9e9af3925a16dcf16b6e5c19acd3")
setManifestid(1447001, "2451787983016277718", 22540914464)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358")
setManifestid(228988, "6645201662696499616", 22411856)

-- [Shared Dependencies]
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
setManifestid(228990, "1829726630299308803", 100658080)

-- [DLC Entitlements]
addappid(1525820, 1)
addappid(1525840, 1)

-- ============================================================
-- Total Depots: 3
-- Shared Depots: 1
-- DLCs:         2
-- ============================================================
