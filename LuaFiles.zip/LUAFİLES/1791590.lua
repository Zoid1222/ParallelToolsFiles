-- ============================================================
-- CRACK WORLD AUTOMATED STEAM CONFIG
-- Generated and compiled by Crack World
-- ============================================================
-- Title:   Sunset Hills
-- AppID:   1791590
-- Created: July 15, 2026 at 01:19:52 PM
-- Discord: https://discord.gg/crackworld
-- ============================================================

-- [Core Application]
addappid(1791590) -- Sunset Hills

-- [Content Depots]
addappid(1791591, 1, "e02d286317336282bcd3d5c676620b5e49946ccc92fb4c7c4fbbab27f494bc17")
setManifestid(1791591, "136385036822681855", 2420032720)
addappid(1791592, 1, "eddb467068198c7c2b8fc41c94df028118d3b82926de97e8e280135b15364d5a")
setManifestid(1791592, "4440394224276776740", 2410758112)
addappid(1791593, 1, "344f19bc8a7999c418b744571efcded013b13997eaa0f725090bb5c7a6a06a78")
setManifestid(1791593, "5774152598159473317", 2422572976)
addappid(1791594, 1, "1c634c0168c763c06499b52c75f2acc5b314fcfd739af52a5f2728539a4fb31b")
setManifestid(1791594, "3478867315931986281", 2412359424)
addappid(3399561, 1, "83fa98aba29ca97dbaf116db8c65ef22dc2db91026ca8251bafe94d53a519f54")
setManifestid(3399561, "5663305058185025314", 328114560)

-- [DLC Entitlements]
addappid(3399560, 1)
addappid(4296440, 1)

-- ============================================================
-- Total Depots: 5
-- Shared Depots: 0
-- DLCs:         2
-- ============================================================
