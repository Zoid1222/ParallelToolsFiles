-- ============================================================
-- CRACK WORLD AUTOMATED STEAM CONFIG
-- Generated and compiled by Crack World
-- ============================================================
-- Title:   MotoGP™20
-- AppID:   1161490
-- Created: July 15, 2026 at 01:27:07 PM
-- Discord: https://discord.gg/crackworld
-- ============================================================

-- [Core Application]
addappid(1161490) -- MotoGP™20

-- [Content Depots]
addappid(1161491, 1, "4cb6b10470f48d200134fdef9687805d97b7aabdbab2b7a6d3c27c87ab1f3cab")
setManifestid(1161491, "1259652244580870879", 22821903856)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5")
setManifestid(228986, "8782296191957114623", 23045488)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e")
setManifestid(228987, "4302102680580581867", 22936736)

-- [Shared Dependencies]
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
setManifestid(228990, "1829726630299308803", 100658080)

-- [DLC Entitlements]
addappid(1176700, 1)

-- ============================================================
-- Total Depots: 4
-- Shared Depots: 1
-- DLCs:         1
-- ============================================================
