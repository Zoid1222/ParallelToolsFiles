-- ============================================================
-- CRACK WORLD AUTOMATED STEAM CONFIG
-- Generated and compiled by Crack World
-- ============================================================
-- Title:   Kindergarten 2
-- AppID:   1067850
-- Created: July 15, 2026 at 01:17:12 PM
-- Discord: https://discord.gg/crackworld
-- ============================================================

-- [Core Application]
addappid(1067850) -- Kindergarten 2

-- [Content Depots]
addappid(1067851, 1, "e0607940b6fe9ca06f82a11e911ea1adaac05771e3601e898b420add1c69b84c")
setManifestid(1067851, "9111284029029028489", 55823280)
addappid(1067852, 1, "c1a72252faf7b567591c555dc118c95d80b2038e27c452ff082a4fa833442df3")
setManifestid(1067852, "8775913596936263416", 62721248)
addappid(1067853, 1, "2448db16e64fadcaa8c5c86011df00808c5b607101aeee3cbbb110bf895d0781")
setManifestid(1067853, "1437063333715820272", 56700640)

-- ============================================================
-- Total Depots: 3
-- Shared Depots: 0
-- DLCs:         0
-- ============================================================
