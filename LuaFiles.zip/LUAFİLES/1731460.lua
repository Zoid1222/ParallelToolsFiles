-- ============================================================
-- CRACK WORLD AUTOMATED STEAM CONFIG
-- Generated and compiled by Crack World
-- ============================================================
-- Title:   LEGO® Brawls
-- AppID:   1731460
-- Created: July 15, 2026 at 11:27:32 AM
-- Discord: https://discord.gg/crackworld
-- ============================================================

-- [Core Application]
addappid(1731460) -- LEGO® Brawls

-- [Content Depots]
addappid(1731461, 1, "c83939be400cd17d31bc1b24c72fdc5191bdc811be3abdb8efaca4c1bb497aa6")
setManifestid(1731461, "7827546601216054581", 2306862624)

-- ============================================================
-- Total Depots: 1
-- Shared Depots: 0
-- DLCs:         0
-- ============================================================
