-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1238020)
addappid(228981)
setManifestid(228981,"7613356809904826842")
addappid(228982)
setManifestid(228982,"6413394087650432851")
addappid(229031)
setManifestid(229031,"7746630274301172884")
addappid(1238021,0,"e997f7dbfb86ef4f47e7cd765bf63931f554188b44b91c3afff856e446a0e4a4")
setManifestid(1238021,"775751148090698423")
addappid(1238022,0,"3cb7a121dab6ddfa948d20dae46362c14551ac652e12f6a61734a512fb0bd2e7")
setManifestid(1238022,"6065176391144189191")
addappid(1238023,0,"321db027fcd7979b66e4c0c918934ac3bf9f484159e1d6d6f131ed83064de2a9")
setManifestid(1238023,"8389333103373451840")
addappid(1238024,0,"c5c9739b981702ca866e9fc3423da7b0bd575bdfa4fc480aa44cf6a2f60a62ef")
setManifestid(1238024,"9006783940413297977")
addappid(1238026,0,"52596a79fa4b3ecd7d273f43eddb91a2629d8d95dfc0f4245b842c0329758286")
setManifestid(1238026,"1449026345622011741")