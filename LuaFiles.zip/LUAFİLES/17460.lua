-- ============================================================
-- CRACK WORLD AUTOMATED STEAM CONFIG
-- Generated and compiled by Crack World
-- ============================================================
-- Title:   Mass Effect (2007)
-- AppID:   17460
-- Created: July 15, 2026 at 10:58:08 AM
-- Discord: https://discord.gg/crackworld
-- ============================================================

-- [Core Application]
addappid(17460) -- Mass Effect (2007)

-- [Content Depots]
addappid(17461, 1, "b2984ca279c5780917e0d8b1d37281ac2600c18a7b174a0fafa4b407b4616600")
setManifestid(17461, "3291123364866001389", 0)
addappid(17462, 1, "15fba131deac12f505b2c641d03931b26733d644af3ccc72734e0ccbf5cf78eb")
setManifestid(17462, "1494229070932282596", 0)
addappid(17463, 1, "2246aee293b06db3a9cc2588f0a9eb15ccb60f7b2ca44e1aaeee765943a33e22")
setManifestid(17463, "8862550287626042070", 0)
addappid(17464, 1, "5aa17cd19143d61105440d65580d2e7aa38dd0912ced242ae77c4a8a62c5fcc8")
setManifestid(17464, "875616295590085358", 0)
addappid(17465, 1, "d72351f6844b8159271b23668d1ee985dc5d0e5ff07d2d635a420c96b733723b")
setManifestid(17465, "2275238411588356044", 0)
addappid(17466, 1, "ce90e0ac9b588ed519637077b97cf02b36feee4e725a98b2f3d6536e8e2f1b6f")
setManifestid(17466, "2709237609878894253", 0)

-- ============================================================
-- Total Depots: 6
-- Shared Depots: 0
-- DLCs:         0
-- ============================================================
