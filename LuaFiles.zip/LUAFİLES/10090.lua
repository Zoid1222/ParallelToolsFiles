-- ============================================================
-- CRACK WORLD AUTOMATED STEAM CONFIG
-- Generated and compiled by Crack World
-- ============================================================
-- Title:   Call of Duty: World at War
-- AppID:   10090
-- Created: July 15, 2026 at 12:40:25 PM
-- Discord: https://discord.gg/crackworld
-- ============================================================

-- [Core Application]
addappid(10090) -- Call of Duty: World at War

-- [Content Depots]
addappid(10091, 1, "10ec612dbb207b40a95f3d87dfa3ff720d38ae05a9cacedba92b2c584451bf9b")
setManifestid(10091, "5566849738478017518", 0)
addappid(10092, 1, "73dd3d3391cf0a30abe562035102c9d47b5d8b8ac6f48d8e574b5501926a5bbc")
setManifestid(10092, "3607600095703252129", 0)
addappid(10093, 1, "2c33b9a6afc043bce38f9c0ba564194895df35c12a885b7bf4cfc6c2e1a18bd2")
setManifestid(10093, "6144874664931741841", 0)
addappid(10094, 1, "7983e119dfd3586cc64677816aa111a598ba49e1d7e92c6b4db8cc9242ecdb86")
setManifestid(10094, "8930507410861259500", 0)
addappid(10095, 1, "fe273171200d3e2271a7dddc4064869e3e4966799e710e805be043c2c30ad554")
setManifestid(10095, "1277981520695176614", 0)
addappid(10096, 1, "e2dbc935ca2ae935ac53479fd77846231acb660baf06b3535d76abc4ccf61c81")
setManifestid(10096, "6181330962488495469", 0)
addappid(10097, 1, "e416f35d0a6911df372411ff0e1dd8ecfec26424c41e0dfe24c4f5db9e1804d1")
setManifestid(10097, "2802736360734339490", 0)

-- ============================================================
-- Total Depots: 7
-- Shared Depots: 0
-- DLCs:         0
-- ============================================================
