-- ============================================================
-- CRACK WORLD AUTOMATED STEAM CONFIG
-- Generated and compiled by Crack World
-- ============================================================
-- Title:   MotoGP™22
-- AppID:   1710580
-- Created: July 15, 2026 at 01:29:38 PM
-- Discord: https://discord.gg/crackworld
-- ============================================================

-- [Core Application]
addappid(1710580) -- MotoGP™22

-- [Content Depots]
addappid(1710581, 1, "f6e8c38bef29f5559860475cbb0db2c258a195c4a4673cc63f0b2830b696027a")
setManifestid(1710581, "1725695274523501194", 29558334544)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358")
setManifestid(228988, "6645201662696499616", 22411856)

-- [Shared Dependencies]
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
setManifestid(228990, "1829726630299308803", 100658080)

-- [DLC Entitlements]
addappid(1876100, 1)
addappid(1876110, 1)

-- ============================================================
-- Total Depots: 3
-- Shared Depots: 1
-- DLCs:         2
-- ============================================================
