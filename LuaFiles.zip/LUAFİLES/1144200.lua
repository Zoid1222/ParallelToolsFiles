-- ============================================================
-- CRACK WORLD AUTOMATED STEAM CONFIG
-- Generated and compiled by Crack World
-- ============================================================
-- Title:   Ready or Not
-- AppID:   1144200
-- Created: July 15, 2026 at 01:46:00 PM
-- Discord: https://discord.gg/crackworld
-- ============================================================

-- [Core Application]
addappid(1144200, 1, "fb29b3865255ec0e9230c029502cd87b8626fd12f9bdb2fa3df6cddf34e17179") -- Ready or Not

-- [Content Depots]
addappid(1144201, 1, "b9236894ba071d12dd117ce16220fefeb20574d7c6f7d2170e3113346867f3d6")
setManifestid(1144201, "6744259790683578909", 41462727280)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d")
setManifestid(229007, "4477590687906973371", 118846656)

-- [Shared Dependencies]
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
setManifestid(228989, "5753583882400741046", 25108528)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
setManifestid(228990, "1829726630299308803", 100658080)
addappid(1844910, 1)

-- [DLC Entitlements]
addappid(3015760, 1)
addappid(3174120, 1)
addappid(4224910, 1)

-- ============================================================
-- Total Depots: 5
-- Shared Depots: 3
-- DLCs:         3
-- ============================================================
