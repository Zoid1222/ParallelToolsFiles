-- ============================================================
-- CRACK WORLD AUTOMATED STEAM CONFIG
-- Generated and compiled by Crack World
-- ============================================================
-- Title:   The Outer Worlds 2
-- AppID:   1449110
-- Created: July 15, 2026 at 01:48:04 PM
-- Discord: https://discord.gg/crackworld
-- ============================================================

-- [Core Application]
addappid(1449110, 1, "96501dedb573e5800c3f202d6b726f4604e982ad55e8d2cba564275bd4b5a581") -- The Outer Worlds 2

-- [Content Depots]
addappid(1449111, 1, "1691760a5a08bde773f0880b6741283070c2c3931c41a09cab6682e29171c563")
setManifestid(1449111, "3632718276211834287", 81244836080)
addappid(3729850, 1, "5de7b19426b9195dd06c2774cb6432657fb1a818723432602636beb88dce3dd4")
setManifestid(3729850, "7345451025778384948", 6249987360)

-- [Shared Dependencies]
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
setManifestid(228989, "5753583882400741046", 25108528)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
setManifestid(228990, "1829726630299308803", 100658080)
addappid(3729860, 1)
addappid(3729880, 1)
addappid(3729910, 1)
addappid(3938110, 1)
addappid(4055350, 1)

-- ============================================================
-- Total Depots: 9
-- Shared Depots: 7
-- DLCs:         0
-- ============================================================
