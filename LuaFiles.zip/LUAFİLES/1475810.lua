--
--   Steam App ID: 1475810 Lua and Manifest
--
--   Generated & Provided by Contrary Server
--   Join us   ->  https://discord.gg/5GyajGM34j
--   Website   ->  https://contrary-downloader.vercel.app/
--
--   Manifests verified & assembled by the Contrary Pipeline.
--   All depot data is cross-validated against live Steam Depots.
--   Use it, enjoy it, come back for more.  o7
--
--------------------------------------------------------------

addappid(1475810)
addappid(1475811,0,"6044597d5ce5e2a639d6651712701e816115dca897c115e8cd756c0b2cae4454")
setManifestid(1475811,"4910392376862342847")
addappid(1475812,0,"3943ef5d4b3a97877847fe80d0e0662bf583777800d70f80a04946dd3ff39143")
setManifestid(1475812,"679915731015348045")