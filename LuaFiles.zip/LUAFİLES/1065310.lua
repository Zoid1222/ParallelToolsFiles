addappid(1065310)
addappid(1065311, 1, "fad466752e88e3caf8ad1aa7d471043f04aa0ae7c0074b107fb4c53af267f8f6")
setManifestid(1065311, "7110952012124972666", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]