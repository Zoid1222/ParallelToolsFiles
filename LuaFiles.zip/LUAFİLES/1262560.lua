-- ============================================================
-- CRACK WORLD AUTOMATED STEAM CONFIG
-- Generated and compiled by Crack World
-- ============================================================
-- Title:   Need for Speed™ Most Wanted
-- AppID:   1262560
-- Created: July 15, 2026 at 10:34:51 AM
-- Discord: https://discord.gg/crackworld
-- ============================================================

-- [Core Application]
addappid(1262560) -- Need for Speed™ Most Wanted

-- [Content Depots]
addappid(1262561, 1, "efa75faca21a0fb0054a21ac3e31e6ed2ad049348ae2f7007c887d8f2568b273")
setManifestid(1262561, "8159337960243801699", 5278803840)
addappid(1262562, 1, "e81fa48076dc629f0421911707222fd0f4f296854920a62aea3cf55d4792ae71")
setManifestid(1262562, "5012803750226627305", 284676640)
addappid(1262563, 1, "6056a4781562321662ed92a5ff2b899485933a69047bfaac5500f78076634ba5")
setManifestid(1262563, "7921462770404366095", 284680704)
addappid(1262564, 1, "5ac062a0a77e8b5837947cbbb2d35fa09f7e637bcf43d1824e6dbc14986b8346")
setManifestid(1262564, "4242758401599755215", 279264912)
addappid(1262565, 1, "0d3366512ced6d106d39269d7bf0c8718381d8341f3151bc7fab5b41e3ead6e7")
setManifestid(1262565, "2380870759557892643", 162926416)
addappid(1262566, 1, "9ee044b8300ff406d6f010c132d0e009338a179a70929b51536752c3e815fb33")
setManifestid(1262566, "5039871595179445303", 275270208)
addappid(1262567, 1, "468c5a37ef929feeabe730917447d7a35aa9e606bbb3965154a1c4260d08a1ce")
setManifestid(1262567, "2969329943246974267", 273781488)
addappid(1262568, 1, "1296ae0139d462480d8e4c578b7a9448a8cb32bd12143a3cf5af089b08cef4db")
setManifestid(1262568, "2538938085050636979", 151413472)
addappid(1262569, 1, "dfed5678965f177f52ce0860e76eee55d17bc127011b7e1006a4b60e784b7766")
setManifestid(1262569, "5285949095913521388", 284677392)
addappid(1262574, 1, "0a3273ccca15cafd9275404c5b0a87fd19a76fc604aec9b770c7ddcd487b2347")
setManifestid(1262574, "2004072646874807804", 284680208)
addappid(1262575, 1, "c61be8c9f08f05785e5ec1460b8a8e4a9ae205b774bc72267043f2b6fb6c040f")
setManifestid(1262575, "846617153359097864", 174989424)
addappid(1262576, 1, "f88be6a7f2c1edb2e5d6997388e72acade24f72a085fe1405e4f58f083e51f97")
setManifestid(1262576, "3618581195646082986", 284681984)
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491")
setManifestid(3340991, "2155225770093841476", 239222800)

-- [Shared Dependencies]
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
setManifestid(228990, "1829726630299308803", 100658080)
addappid(1271370, 1)

-- [DLC Entitlements]
addappid(1262570, 1)
addappid(1262571, 1)
addappid(1262572, 1)
addappid(1262573, 1)
addappid(1271371, 1)

-- ============================================================
-- Total Depots: 15
-- Shared Depots: 2
-- DLCs:         5
-- ============================================================
