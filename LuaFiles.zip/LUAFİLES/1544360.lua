-- ============================================================
-- CRACK WORLD AUTOMATED STEAM CONFIG
-- Generated and compiled by Crack World
-- ============================================================
-- Title:   LEGO® Builder's Journey
-- AppID:   1544360
-- Created: July 15, 2026 at 11:26:57 AM
-- Discord: https://discord.gg/crackworld
-- ============================================================

-- [Core Application]
addappid(1544360) -- LEGO® Builder's Journey

-- [Content Depots]
addappid(1544361, 1, "f68c8ea838a50a342ba77fc9816a952a46f6a54a86d821c3adb661e4b9455868")
setManifestid(1544361, "8880740850063669439", 1046505616)

-- ============================================================
-- Total Depots: 1
-- Shared Depots: 0
-- DLCs:         0
-- ============================================================
