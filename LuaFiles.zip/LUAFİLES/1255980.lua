-- ============================================================
-- CRACK WORLD AUTOMATED STEAM CONFIG
-- Generated and compiled by Crack World
-- ============================================================
-- Title:   Portal Reloaded
-- AppID:   1255980
-- Created: July 15, 2026 at 01:16:37 PM
-- Discord: https://discord.gg/crackworld
-- ============================================================

-- [Core Application]
addappid(1255980) -- Portal Reloaded

-- [Content Depots]
addappid(1255981, 1, "dc98a3763d3f305b4ec2f52bdab9d93fcd7edc25ff86941b4a645808928a765b")
setManifestid(1255981, "3215218433401002224", 2694364992)
addappid(1255982, 1, "c45de80198a85a5d2f5128905433e651884ebabdd0a640cfbd5a7ddf8dce4b09")
setManifestid(1255982, "707421310887317428", 30593440)
addappid(1255983, 1, "6e5218c30d056e7bdc1ebd853b355432e6c17bec69bea34f09faafc96e9d23e5")
setManifestid(1255983, "290508551967417027", 27420736)
addappid(1255984, 1, "e7182b8d7f301de4150fa8bc6058a8ee245ed6643e44171a28935112d68ffe07")
setManifestid(1255984, "6095143477847595406", 22192368)

-- ============================================================
-- Total Depots: 4
-- Shared Depots: 0
-- DLCs:         0
-- ============================================================
